# vim-what
Learn and remember vim commands

Project inspired by all the wonderful Vim plugin makers, cheat sheet guides and general challenge to learn Vim.

With Special thanks to [Jon](http://www.viemu.com/a_vi_vim_graphical_cheat_sheet_tutorial.html)

Next steps:
* Load .vimrc, parse Plugins and custom maps
* Allow longer key combos to be used on help. ie: yip (yank inner parapaph)
* Grab alphabet data from : https://github.com/alexbaldwin/vimtips/blob/gh-pages/index.html

